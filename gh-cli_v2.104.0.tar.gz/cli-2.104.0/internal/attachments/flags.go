package attachments

import (
	"errors"
	"fmt"
	"os"
	"strings"

	"github.com/spf13/cobra"
	"github.com/spf13/pflag"
)

const (
	flagName       = "attach"
	maxAttachments = 50
)

// errEmptyPath is reported for a --attach that named no file, whether the flag
// held nothing else or the empty value sat beside a real one.
var errEmptyPath = errors.New("cannot attach an empty path; --attach needs a file path")

// Flag holds the repeatable attachment flag and the values it parsed.
type Flag struct {
	flag   *pflag.Flag
	values []string
}

// AddFlag registers the repeatable --attach flag on cmd.
func AddFlag(cmd *cobra.Command) *Flag {
	f := &Flag{}
	// A string slice would split on commas, which are legal in filenames.
	cmd.Flags().StringArrayVar(&f.values, flagName, nil, "Attach an image or video `file`, in '<file>#<image alt text>' format")
	f.flag = cmd.Flags().Lookup(flagName)
	return f
}

// Changed reports whether the attachment flag was passed.
func (f *Flag) Changed() bool {
	return f.flag.Changed
}

// Count returns the number of supplied attachment values before validation.
// Absent flags count as zero; empty paths and values over the limit still count.
func (f *Flag) Count() int {
	return len(f.values)
}

// UserAssets validates the files named by the attachment flag, keeping them in
// the order they were written. It returns nothing when the flag was not passed.
func (f *Flag) UserAssets() ([]UserAsset, error) {
	if !f.Changed() {
		return nil, nil
	}
	if len(f.values) > maxAttachments {
		return nil, fmt.Errorf("`--attach` accepts at most %d values per command", maxAttachments)
	}
	return userAssetsFromArgs(f.values)
}

func userAssetsFromArgs(args []string) ([]UserAsset, error) {
	// --attach "" is a user error.
	if len(args) == 0 {
		return nil, errEmptyPath
	}

	resolvedAssets := make([]UserAsset, 0, len(args))
	for _, arg := range args {
		a, err := assetFromArg(arg)
		if err != nil {
			return nil, err
		}

		// The same file under two names is a user error.
		for _, seen := range resolvedAssets {
			if os.SameFile(seen.getAsset().info, a.getAsset().info) {
				return nil, fmt.Errorf("%s and %s are the same file; attached files must be unique", seen.Path(), a.Path())
			}
		}
		resolvedAssets = append(resolvedAssets, a)
	}

	return resolvedAssets, nil
}

// assetFromArg turns one --attach argument into a UserAsset.
func assetFromArg(arg string) (UserAsset, error) {
	path, alt := SplitFileArg(arg)

	if path == "" {
		return nil, errEmptyPath
	}

	if path == "-" {
		return nil, errors.New("cannot attach standard input; --attach needs a file path")
	}

	return newAsset(path, alt)
}

// SplitFileArg splits an argument of the form <file>#<text>, the way --attach
// reads '<file>#<image alt text>'. An existing path wins over the delimiter,
// since `#` is legal in filenames. path is arg itself when there was no `#` to
// split at. gh issue artifact create uses it for <file>#<name>, so `#` means
// the same there as in --attach.
func SplitFileArg(arg string) (path, text string) {
	if _, err := os.Stat(arg); err == nil {
		return arg, ""
	}
	// Scan from the last hash to the first, so the longest path that exists
	// wins. That continues the rule above, where the whole argument is the
	// longest match of all, and it leaves a hash inside the text usable.
	for i := strings.LastIndex(arg, "#"); i > 0; i = strings.LastIndex(arg[:i], "#") {
		if _, err := os.Stat(arg[:i]); err == nil {
			return arg[:i], arg[i+1:]
		}
	}
	// No candidate exists, so the argument names a file that is not there. The
	// last hash keeps the error naming the path a reader would expect.
	if idx := strings.LastIndex(arg, "#"); idx > 0 {
		return arg[:idx], arg[idx+1:]
	}
	return arg, ""
}
